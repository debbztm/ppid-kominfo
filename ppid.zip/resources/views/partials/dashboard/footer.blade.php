<footer class="footer">
    <div class="container-fluid">
        <div class="copyright mx-auto">
                Copyright © 2023 Dinas Energi Sumber Daya Mineral (ESDM) Provinsi Jawa Tengah. All right reserved | ESDM Jateng
        </div>
    </div>
</footer>
