<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script>
    window.jQuery || document.write(`<script src="{{ asset('frontend/js/jquery-1.11.3.min.js') }}"><\/script>`)
</script>
<script src="{{ asset('frontend/js/bootstrap.min.js') }}"></script>
<script src="{{ asset('frontend/js/owl.carousel.js') }}"></script>
<script src="{{ asset('frontend/js/jquery.countdown.min.js') }}"></script>
<script src="{{ asset('frontend/js/jquery.mixitup.js') }}"></script>
<script src="{{ asset('frontend/js/Chart.min.js') }}"></script>
<script src="{{ asset('frontend/js/custom-chart.js') }}"></script>
<script src="{{ asset('frontend/js/main.js') }}"></script>
