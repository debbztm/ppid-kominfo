<div class="row mt-3">
    <div class="col-md-6">
        <div class="form-group form-group-default">
            <label for="image">Gambar Logo</label>
            <input class="form-control" id="web_logo" type="file" name="web_logo" placeholder="upload gambar" />
            <small class="text-danger">Max ukuran 200KB</small>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group form-group-default" id="image_preview">

        </div>
    </div>
</div>
