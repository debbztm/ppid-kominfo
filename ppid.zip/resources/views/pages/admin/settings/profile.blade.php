<div class="row mt-3">
    <div class="col-md-12">
        <div class="form-group form-group-default">
            <div id="summernote" name="description"></div>
        </div>
    </div>
</div>
