<div class="row mt-3">
    <div class="col-md-6">
        <div class="form-group form-group-default">
            <label>Facebook</label>
            <input type="text" class="form-control" id="facebook" name="facebook" placeholder="link facebook">
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group form-group-default">
            <label>Twitter</label>
            <input type="text" class="form-control" id="twitter" name="twitter" placeholder="link twitter">
        </div>
    </div>
</div>
<div class="row mt-3">
    <div class="col-md-6">
        <div class="form-group form-group-default">
            <label>Instagram</label>
            <input type="text" class="form-control" id="instagram" name="instagram" placeholder="link instagram">
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group form-group-default">
            <label>Youtube</label>
            <input type="text" class="form-control" id="youtube" name="youtube" placeholder="link youtube">
        </div>
    </div>
</div>
