    <div class="row mt-3">
    <div class="col-md-12">
        <div class="form-group form-group-default">
            <label for="maps_location">Embed Google Maps</label>
            <textarea class="form-control" id="maps_location" name="maps_location" placeholder="link gmaps" rows="3"></textarea>
        </div>
    </div>
    <div class="col-md-12">
        <div class="form-group form-group-default" id="maps_preview">

        </div>
    </div>
</div>
